const express = require('express');
const cheerio = require('cheerio');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;
const TIMEOUT_MS = 10000; // 10s fetch timeout

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

function isValidHttpUrl(input) {
  try {
    const u = new URL(input);
    return u.protocol === 'http:' || u.protocol === 'https:';
  } catch {
    return false;
  }
}

app.post('/api/audit', async (req, res) => {
  const rawUrl = req.body && req.body.url;

  // --- Input validation ---
  if (!rawUrl || typeof rawUrl !== 'string' || !rawUrl.trim()) {
    return res.status(400).json({ error: 'Enter a URL to audit.' });
  }

  const url = rawUrl.trim();

  if (!isValidHttpUrl(url)) {
    return res.status(400).json({
      error: 'That\'s not a valid URL. Include the protocol, e.g. https://example.com',
    });
  }

  // --- Fetch with timeout ---
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), TIMEOUT_MS);
  const startTime = Date.now();

  let response;
  try {
    response = await fetch(url, {
      signal: controller.signal,
      redirect: 'follow',
      headers: {
        'User-Agent':
          'Mozilla/5.0 (compatible; SiteAuditBot/1.0; +https://github.com/)',
        Accept: 'text/html,application/xhtml+xml',
      },
    });
  } catch (err) {
    clearTimeout(timer);
    if (err.name === 'AbortError') {
      return res.status(504).json({
        error: `The page took longer than ${TIMEOUT_MS / 1000}s to respond. It may be slow or unreachable.`,
      });
    }
    return res.status(502).json({
      error:
        'Could not reach that URL. The domain may not exist, the site may be down, or it refused the connection.',
    });
  }
  clearTimeout(timer);

  const responseTimeMs = Date.now() - startTime;
  const contentType = response.headers.get('content-type') || '';

  // --- Reject non-HTML responses cleanly ---
  if (!contentType.toLowerCase().includes('text/html')) {
    return res.status(415).json({
      error: `That URL returned "${contentType.split(';')[0] || 'an unknown content type'}", not an HTML page, so it can't be audited.`,
      httpStatus: response.status,
      responseTimeMs,
    });
  }

  let html;
  try {
    html = await response.text();
  } catch {
    return res.status(502).json({
      error: 'The page responded but its content could not be read.',
    });
  }

  // --- Parse & build report ---
  try {
    const $ = cheerio.load(html);

    const title = $('title').first().text().trim() || null;
    const metaDescription =
      $('meta[name="description"]').attr('content')?.trim() || null;
    const h1Count = $('h1').length;

    let imagesTotal = 0;
    let imagesMissingAlt = 0;
    $('img').each((_, el) => {
      imagesTotal += 1;
      const alt = $(el).attr('alt');
      if (alt === undefined || alt.trim() === '') imagesMissingAlt += 1;
    });

    const bodyText = $('body').text().replace(/\s+/g, ' ').trim();
    const wordCount = bodyText ? bodyText.split(' ').length : 0;

    return res.json({
      url,
      httpStatus: response.status,
      responseTimeMs,
      title,
      metaDescription,
      h1Count,
      imagesTotal,
      imagesMissingAlt,
      wordCount,
    });
  } catch {
    return res.status(500).json({
      error: 'The page was fetched but its HTML could not be parsed.',
    });
  }
});

// Catch-all error handler so nothing ever crashes the process
app.use((err, req, res, next) => {
  console.error('Unhandled error:', err);
  if (res.headersSent) return next(err);
  res.status(500).json({ error: 'Something unexpected went wrong on the server.' });
});

process.on('unhandledRejection', (err) => console.error('Unhandled rejection:', err));

app.listen(PORT, () => {
  console.log(`Audit tool running at http://localhost:${PORT}`);
});
